# def greetings(msg, name):
#     return msg + " " + name

# print(greetings("Good Morning", "Abhijeet"))
# print(greetings("Good Morning", "Subodh"))
# print(greetings("Good Morning", "Ramakant"))

# def Converter(toUnit, factor, offset, input):
#     print(str((offset+input)*factor)+" " + toUnit)

# Converter('km ', 1.6, 0, 10)
# Converter('km ', 1.6, 0, 40)
# Converter('km ', 1.6, 0, 30)
# Converter('km ', 1.6, 0, 10)

# ------------------------------------------------------------
# def greetings(msg):
#     def greet(name):
#         return msg + " " + name
#     return greet

# mGreet = greetings("Good Morning")

# print(mGreet("Abhijeet"))
# print(mGreet("Ramkant"))
# print(mGreet("Subodh"))

def Converter(toUnit, factor, offset):
    def Convert(input):
        print(str((offset+input)*factor)+" " + toUnit)
    return Convert

milesToKm = Converter('km ', 1.6, 0)

milesToKm(10)
milesToKm(20)

usdToinr = Converter(' INR', 67, 0)

usdToinr(100)
usdToinr(150)