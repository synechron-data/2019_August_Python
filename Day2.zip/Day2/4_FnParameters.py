# def add(x=0, y=0):
#     return x+y

# print(add())
# print(add(1))
# print(add(2, 3))

# non-keyworded, variable-length argument list
# def calculate(*numbers):
#     print(numbers)
#     print(type(numbers))
#     sum = 0
#     for n in numbers:
#         sum += n
#     return sum


# print(calculate())
# print(calculate(1))
# print(calculate(1, 2))
# print(calculate(1, 2, 3, 4, 5))
# print(calculate(1, 2, 3, 4, 5, 6, 7, 8, 9))
# print(calculate(*[1, 2, 3, 4, 5, 6, 7, 8, 9]))

# keyworded, variable-length argument list
# def printData(id, name, city):
#     print(id)
#     print(name)
#     print(city)


# printData(id=1, city="Pune", name="Manish")


# def printData(**kwargs):
#     print(kwargs)
#     print(type(kwargs))


# printData(id=1, city="Pune", name="Manish")

# mydict = {"id": 1, "city": "Pune", "name": "Manish"}
# # print(mydict)
# # print(type(mydict))

# printData(**mydict)

# Destructuring of Values
# a = 1
# b = 2

# a, b = (1, 2)

# print(a)
# print(b)

# Destructuring
# mylist = [10, 20, 30, 40, 50]

# # a = mylist[0]
# # b = mylist[1]
# # rest = mylist[2:]
# a, b, *rest = mylist

# print(a)
# print(b)
# print(rest)
# print(type(rest))

# a, *c, b = [1, 2, 3, 4]
# a, _, _, b = [1, 2, 3, 4]

# print(a)
# print(c)
# print(b)
