import words
items = words.fetch_words('http://sixty-north.com/c/t.txt')
words.print_items(items)

# from words import fetch_words
# fetch_words()

# from words import fetch_words as fetch
# fetch()