from datetime import date

today = date.today()
print("Day: ", today.day)
print("Month: ", today.month)
print("Year: ", today.year)