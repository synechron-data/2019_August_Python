import csv

# myData = [
#     ["fname", "lname", "city"],
#     ["Abhijeet", "Gole", "Pune"],
#     ["Manish", "Sharam", "Kolkata"]
# ]

# myFile = open('test.csv', 'w', newline='')

# with myFile:
#     writer = csv.writer(myFile)
#     writer.writerows(myData)

# print('CSV File is written')

# ----------------------------------------- Read

# with open('test.csv') as File:
#     reader = csv.reader(File, delimiter=',')

#     for row in reader:
#         print(row)

result= []

with open('test.csv') as File:
    reader = csv.DictReader(File)
    for row in reader:
        result.append(row)

print(result)