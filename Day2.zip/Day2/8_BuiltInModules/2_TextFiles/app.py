fo = open("test.txt", "w+")

# print("File Name:", fo.name)
# print("Closed:", fo.closed)
# print("Mode:", fo.mode)

fo.write("This is just an example of File Write.\nUsing Python")

position = fo.tell()
print("Current Cursor Position: ", position)

position = fo.seek(0)
print("Current Cursor Position: ", position)

# str = fo.read()
# str = fo.read(10)
# str = fo.readline()
# print(str)

# while True:
#     s = fo.readline()
#     if not s:
#         break
#     print(s)

for line in fo.readlines():
    print(line)

fo.close()
