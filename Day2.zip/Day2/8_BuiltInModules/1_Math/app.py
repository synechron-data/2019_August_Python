# import math

# # result = math.sqrt(81)
# # print(result)

# n = 5
# k = 3
# r = math.factorial(n) / (math.factorial(k) * math.factorial(n-k))
# print(r)

# ---------------------------------------------------
# from math import factorial

# n = 5
# k = 3
# r = factorial(n) / (factorial(k) * factorial(n-k))
# print(r)

# -------------------------------------------------------
from math import factorial as fac

n = 5
k = 3
r = fac(n) / (fac(k) * fac(n-k))
print(r)
