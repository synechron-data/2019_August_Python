# h = 40

# if h > 50:
#     print("Greater than 50")
# else:
#     print("Smaller than 50")

# h = 10

# if h > 50:
#     print("Greater than 50")
# elif h < 20:
#     print("Less than 20")
# else:
#     print("50 or Smaller")

# s = "abc"

# if s:
#     print("s is", s)
# else:
#     pass

# while True:
#     r = input("Enter a number: ")
#     if int(r) == 6:
#         continue
#     print("You entered", r)
#     if int(r) % 7 == 0:
#         break

# for item in range(6):
#     print(item)

numList = []

n = int(input("Number of items, you want to add: "))
# print(n)

for i in range(0, n):
    inp = int(input("Enter a number: "))
    numList.append(inp)

print("List Items:", numList)

# result = {}

# for i in numList:
#     count = numList.count(i)
#     result[i] = count

result = {i: numList.count(i) for i in numList}

print("Item Occurance:", result)
