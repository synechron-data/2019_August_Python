# def hello():
#     pass

# hello()


def hello():
    print('hello world')

print(hello)
print(type(hello))

# hello()


# def add(x, y):
#     return x+y


# def add(x, y, z):
#     return x+y+z


# print(add(2, 3))
# print(add(2, 3, 4))


# def addAll(numbers):
#     print(type(numbers))
#     sum = 0
#     for n in numbers:
#         sum += n
#     return sum


# print(addAll([1, 2, 3, 4, 5, 6, 7]))
# print(addAll(["ABC","XYZ"]))
# print(addAll(2))

# addAll(2)
# addAll([2, 3])
# addAll("2")
# addAll({2: 1})
