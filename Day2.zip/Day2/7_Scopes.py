# L - Local
# E - Enclosing
# G - Global
# B - BuiltIn

# x = 10

# def show():
#     x = 1000
#     print("Inside, x is:", x)

# show()
# print("Outside, x is:", x)

# x = 10


# def show():
#     global x
#     # x = 1000
#     x += 1000
#     print("Inside, x is:", x)


# show()
# print("Outside, x is:", x)

x = 10


# def show():
#     global x
#     x = 0
#     def check():
#         x = 1000
#         print("Inside Check, x is:", x)
#     check()
#     print("Inside Show, x is:", x)

# def show():
#     x = 0
#     def check():
#         # global x
#         nonlocal x
#         x = 1000
#         print("Inside Check, x is:", x)
#     check()
#     print("Inside Show, x is:", x)


# show()
# print("Outside, x is:", x)

# def len(in_var):
#     print('called mylen() function')
#     return 0


def aFunc(inp):
    length = len(inp)
    print('Length is: ', length)

aFunc("Hello World")