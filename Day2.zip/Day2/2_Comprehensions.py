# countrycapital = {'India': 'Delhi', 'Morocco': 'Rabat',
#                   'Netherlands': 'Amsterdam', 'UAE': 'Abu Dhabi'}

# # capitalcountry = {}

# # for (key, value) in countrycapital.items():
# #     capitalcountry[value] = key

# capitalcountry = {value: key for key, value in countrycapital.items()}

# print(countrycapital)
# print(capitalcountry)

# create a list which contains square of all odd numbers from range 1 to 10

# oddSquares = []

# for item in range(1, 11, 2):
#     oddSquares.append(item**2)

# oddSquares = [item**2 for item in range(1, 11, 2)]

# print(oddSquares)

# oddSquares = []

# for x in range(1, 11):
#     if x % 2 == 1:
#         oddSquares.append(x**2)

# oddSquares = [x**2 for x in range(1, 11) if x % 2 == 1]

# print(oddSquares)


# create a list which contains square of all numbers from range 1 to 10

# allSquares = [x**2 for x in range(1, 11)]
# print(allSquares)

# dictSquares = {x: x**2 for x in range(1, 11)}
# print(dictSquares)

words = """Lorem ipsum dolor sit amet consectetur adipisicing elit.
Reiciendis eum, laudantium harum voluptas, debitis aliquid porro accusantium ducimus corporis 
sit aspernatur tenetur magnam vitae nesciunt officiis aperiam cupiditate similique explicabo.""".split()

print(words)

# lengths = []
# for word in words:
#     lengths.append(len(word))

lengths = [len(word) for word in words]

print(lengths)
