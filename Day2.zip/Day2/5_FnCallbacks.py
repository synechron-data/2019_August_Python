# # Dev 1
# def calculate(successCB, *numbers):
#     # Consider this process as long running call
#     sum = 0
#     for n in numbers:
#         sum += n
#     successCB(sum)


# # Dev 2
# def printResult(result):
#     print(result)


# calculate(printResult, 1, 2, 3, 4, 5, 6, 7, 8, 9)
# calculate(lambda r: print("Lambda", r), 1, 2, 3, 4, 5, 6, 7, 8, 9)


# def add1(x, y):
#     return x+y


# add2 = lambda x, y: x+y

# print(add1(2, 3))
# print(add2(2, 3))

numArr = [1, 2, 3, 4, 5, 6, 7, 8, 9]


def filterLogic(item):
    return item % 2 == 0


result2 = []

for item in numArr:
    if(filterLogic(item)):
        result2.append(item)
print(result2)

result = list(filter(filterLogic, numArr))
print(result)

result1 = list(filter(lambda item: item % 2 == 0, numArr))
print(result1)
