# name1 = "Synechron"
# name2 = 'Synechron'

# print(name1)
# print(type(name1))

# print(name2)
# print(type(name2))

# message = """Hi Synechron

#     Hello How are you

# Bye"""

# print(message)
# print(type(message))

# print("Synechron\tPune")
# print("\u2192")

# print("Synechron'Pune")
# print("Synechron\"Pune")
# print("Synechron\nPune")
# print(r"Synechron\nPune")

a = 10
b = "Hello"
print(b+str(a))
