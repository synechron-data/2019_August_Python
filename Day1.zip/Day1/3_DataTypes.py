# int, float & bool

# # int       Signed & Unlimited Precision

# a = 10  # Decimal type
# print(a)
# print(type(a))

# b = 0b10  # Binary type
# print(b)
# print(type(b))

# c = 0o10  # Octal type
# print(c)
# print(type(c))

# d = 0x10  # Hex type
# print(d)
# print(type(d))

# e = int(3.5)  # Ctor
# print(e)
# print(type(e))

# f = int(-3.5)  # Ctor
# print(f)
# print(type(f))

# g = int("45")  # Ctor
# print(g)
# print(type(g))

# g = int("45")  # Ctor
# print(g)
# print(type(g))

# h = int("1010", 4)  # Ctor
# print(h)
# print(type(h))

# float - Docuble Precision (64 bit)

# a = 3.125
# print(a)
# print(type(a))


# b = 3e8
# print(b)
# print(type(b))

# c = 15e-38
# print(c)
# print(type(c))

# d = float(7)
# print(d)
# print(type(d))

# e = float("1.543")
# print(e)
# print(type(e))

# g = float("nan")
# print(g)
# print(type(g))

# h = float("inf")
# print(h)
# print(type(h))

# i = float("-inf")
# print(i)
# print(type(i))

# k = None
# print(k)
# print(k is None)
# print(type(k))

# a = True
# print(a)
# print(type(a))

# b = False
# print(b)
# print(type(b))

# c = bool(0)
# print(c)
# print(type(c))

print(bool(1))
print(bool(0))
print(bool(-1))
print(bool(""))
print(bool("abc"))
print(bool("nan"))
print(bool(None))