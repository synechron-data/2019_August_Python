# obj = {}
# print(obj)
# print(type(obj))

obj1 = {1, 2, 3, 4, 5, "Pune", (1, 2)}
# print(obj1)
# print(type(obj1))

obj1.add(6)
obj1.add(2)

obj1.update([10, 20])

for item in obj1:
    print(item)
