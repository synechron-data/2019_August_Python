# arr = [10, 20, 30, 40, 50]
# print(arr)
# print(type(arr))

# arr1 = [10, 20, 30, 40, 50, 10]
# arr2 = [100, 200]

# print(10 in arr1)
# newArr = arr1 + arr2    #Concat Lists
# print(newArr)

# mArr = arr1 * 3
# print(mArr)

# print(max(arr1))
# print(arr1.count(10))

# print(arr1[2])
# print(arr1[2:4])
# print(arr1[2:5:2])

# arr1.append(60)
# arr1.insert(5, 60)
# arr1.pop(5)
# print(arr1)

# print(arr1)
# arr1.reverse()
# print(arr1)

# print(arr1.index(30))

# arr1.clear()
# print(arr1)


# del arr1
# print(arr1)

# arr1 = [10, 20, 30, 40, 50]

# print(len(arr1))

# arr1.remove(30)

# print(len(arr1))
# print(arr1)

arr1 = [10, [20, 30], 40, 50]
# arr2 = arr1
# arr2 = list.copy(arr1)
arr2 = arr1.copy()

arr2[1][0] = 200

print(arr1)
print(arr2)

# a = 10
# b = a
# b = 20
# b = a

# print(a)
# print(b)
