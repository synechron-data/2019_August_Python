squares = {1: 1, 2: 4, 3: 9, 4: 16, 5: 25}
# print(squares)
# print(type(squares))

# rItem = squares.pop(5)
# print(squares)
# print(rItem)

# del squares[3]
# print(squares)

# squares.clear()
# print(squares)


for item in squares:
    print(item)

for item in squares.keys():
    print(item)

for item in squares.items():
    print(item)

for item in squares.values():
    print(item)

