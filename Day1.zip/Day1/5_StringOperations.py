# a = "Hello"
# print(a*3)
# print(a[1])
# print(a[1:])
# print(a[1:4])

# print("he" in a)

# print("%s Synechron %s - %d" % (a, a, 21))

# a = "Hello Synechron"
# # print(a[0:-2])
# print(a)
# b = a.replace("e", "p")
# print(b)

# message = "{} {} {}".format("Hello", "Synechron", "Hi")
# print(message)

# message = "{1} {2} {0}".format("Hello", "Synechron", "Hi")
# print(message)

# message = "{0} {l} {n}".format("Hello", n = "Synechron", l = "Pune")
# print(message)

# number = 15
# print(number)
# print("{0:b}".format(number))

# a = "hello synechron"
# print(a)
# # print(a.capitalize())
# print(len(a))

# a = "123.45"
# a = "23+2"
# print(a.isnumeric())
# print(a.isdigit())

a = "hello synechron"

print(a)
b = a.encode('cp273','strict')
print(b)
print(b.decode('cp273'))
