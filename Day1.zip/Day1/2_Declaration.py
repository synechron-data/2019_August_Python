# a = "Synechron"
# print(a)

a = "Synechron"
b = 100
print(a)
print(b)

print(type(a))
print(type(b))

a = 200
print(a)
print(type(a))
