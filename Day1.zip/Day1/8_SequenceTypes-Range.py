# myRange = range(1, 10)
myRange = range(1, 20, 2)
print(myRange)
print(type(myRange))

for item in myRange:
    print(item)

print("Done")
