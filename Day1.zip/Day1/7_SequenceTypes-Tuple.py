# myTuple = (10, 20, 30, 40, 50)
# print(myTuple)
# print(type(myTuple))

# myTuple[0] = 60
# print(myTuple)

# myTuple.clear()
# print(len(myTuple))

# print(myTuple[0])

# del myTuple
# print(myTuple)

# myTuple = (10,)*3

# print(myTuple)

mylist = [10,]*3
print(mylist)
print(type(mylist))

mytuple = tuple(mylist)
print(mytuple)
print(type(mytuple))

